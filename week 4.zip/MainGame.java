/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package maingame;

/**
 *
 * @author USER
 */
import javax.swing.*;
import java.awt.*;
import java.util.HashMap;

public class MainGame extends JFrame {

    private JPanel boardPanel;
    private JLabel[] cells;

    private JLabel player1Label;
    private JLabel player2Label;
    private JLabel diceLabel;
    private JLabel turnLabel;
    private JLabel statusLabel;

    private JButton rollButton;

    private Dice dice;

    private HashMap<Integer, Integer> snakes = new HashMap<>();
    private HashMap<Integer, Integer> ladders = new HashMap<>();

    public MainGame() {

        setTitle("Snake and Ladder Game");
        setSize(1100, 750);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        dice = new Dice();

        createSnakeAndLadder();
        createGUI();

        setVisible(true);
    }

    private void createSnakeAndLadder() {

        snakes.put(98, 12);
        snakes.put(89, 53);
        snakes.put(66, 45);
        snakes.put(54, 31);
        snakes.put(40, 3);

        ladders.put(4, 25);
        ladders.put(13, 46);
        ladders.put(33, 49);
        ladders.put(42, 63);
        ladders.put(50, 69);
    }

    private void createGUI() {

        setLayout(new BorderLayout(10, 10));

        JLabel title = new JLabel(
                "SNAKE AND LADDER GAME",
                SwingConstants.CENTER
        );

        title.setFont(new Font("Arial", Font.BOLD, 28));

        add(title, BorderLayout.NORTH);

        boardPanel = new JPanel();
        boardPanel.setLayout(new GridLayout(10, 10));

        cells = new JLabel[101];

        createBoard();

        add(boardPanel, BorderLayout.CENTER);

        JPanel controlPanel = new JPanel();

        controlPanel.setPreferredSize(new Dimension(250, 600));

        controlPanel.setLayout(
                new BoxLayout(controlPanel, BoxLayout.Y_AXIS)
        );

        JLabel gameInfo = new JLabel("GAME INFO");

        gameInfo.setFont(
                new Font("Arial", Font.BOLD, 20)
        );

        gameInfo.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        player1Label = new JLabel("Player 1: Start");
        player2Label = new JLabel("Player 2: Start");
        diceLabel = new JLabel("Dice Result: -");
        turnLabel = new JLabel("Current Turn: Player 1");
        statusLabel = new JLabel("Game Started");

        rollButton = new JButton("ROLL DICE");

        player1Label.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        player2Label.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        diceLabel.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        turnLabel.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        statusLabel.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        rollButton.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        controlPanel.add(gameInfo);

        controlPanel.add(
                Box.createVerticalStrut(30)
        );

        controlPanel.add(player1Label);

        controlPanel.add(
                Box.createVerticalStrut(15)
        );

        controlPanel.add(player2Label);

        controlPanel.add(
                Box.createVerticalStrut(30)
        );

        controlPanel.add(diceLabel);

        controlPanel.add(
                Box.createVerticalStrut(20)
        );

        controlPanel.add(rollButton);

        controlPanel.add(
                Box.createVerticalStrut(30)
        );

        controlPanel.add(turnLabel);

        controlPanel.add(
                Box.createVerticalStrut(20)
        );

        controlPanel.add(statusLabel);

        add(controlPanel, BorderLayout.EAST);

        rollButton.addActionListener(e -> rollDice());
    }

    private void createBoard() {

        for (int row = 0; row < 10; row++) {

            if (row % 2 == 0) {

                int start = 100 - (row * 10);
                int end = start - 9;

                for (int number = start;
                     number >= end;
                     number--) {

                    addCell(number);
                }

            } else {

                int start = 100 - (row * 10) - 9;
                int end = start + 9;

                for (int number = start;
                     number <= end;
                     number++) {

                    addCell(number);
                }
            }
        }
    }

    private void addCell(int number) {

        JLabel cell = new JLabel(
                String.valueOf(number),
                SwingConstants.CENTER
        );

        cell.setFont(
                new Font("Arial", Font.BOLD, 14)
        );

        cell.setBorder(
                BorderFactory.createLineBorder(
                        Color.BLACK,
                        1
                )
        );

        cell.setOpaque(true);

        if (ladders.containsKey(number)) {

            cell.setText(
                    "<html><center>"
                    + number
                    + "<br>🪜 "
                    + ladders.get(number)
                    + "</center></html>"
            );

            cell.setBackground(
                    new Color(180, 230, 180)
            );

        } else if (snakes.containsKey(number)) {

            cell.setText(
                    "<html><center>"
                    + number
                    + "<br>🐍 "
                    + snakes.get(number)
                    + "</center></html>"
            );

            cell.setBackground(
                    new Color(240, 180, 180)
            );

        } else {

            cell.setBackground(
                    new Color(235, 235, 235)
            );
        }

        cells[number] = cell;

        boardPanel.add(cell);
    }

    private void rollDice() {

        int value = dice.rollDice();

        diceLabel.setText(
                "Dice Result: " + value
        );

        statusLabel.setText(
                "Player 1 rolled " + value
        );
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(
                () -> new MainGame()
        );
    }
}