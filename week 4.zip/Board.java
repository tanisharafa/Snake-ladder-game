/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package maingame;

/**
 *
 * @author USER
 */
import java.util.HashMap;

public class Board {

    private HashMap<Integer, Integer> snakes;
    private HashMap<Integer, Integer> ladders;

    public Board() {

        snakes = new HashMap<>();
        ladders = new HashMap<>();

        snakes.put(98, 12);
        snakes.put(89, 53);
        snakes.put(66, 45);
        snakes.put(54, 31);
        snakes.put(40, 3);

        ladders.put(4, 25);
        ladders.put(13, 46);
        ladders.put(33, 49);
        ladders.put(42, 63);
        ladders.put(50, 69);
    }

    public int checkPosition(int position) {

        if (snakes.containsKey(position)) {
            return snakes.get(position);
        }

        if (ladders.containsKey(position)) {
            return ladders.get(position);
        }

        return position;
    }
}