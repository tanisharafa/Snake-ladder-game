/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package maingame;

/**
 *
 * @author USER
 */
import javax.swing.JFrame;

public class MainGame extends JFrame {

    public MainGame() {
        setTitle("Snake and Ladder Game");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        setVisible(true);
    }

    public static void main(String[] args) {
        new MainGame();
    }
}